import TableroConfigurableV2.*;

public class Main {
    public static void main(String[] args) {
        VentanaPrincipal vt = new VentanaPrincipal();
    }
}